package com.example.currencyi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.currencyi.model.Add
import com.example.currencyi.model.Currency
import com.example.currencyi.model.Views
import com.example.currencyi.ui.Adapter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setup()
    }

    private fun setup() {
        val currencyAdapter = Adapter(
            clickListener = {
                Log.d("currency name:", it.textview)
            }
        )
        val currencyManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        findViewById<RecyclerView>(R.id.recyclerView).apply {
            adapter = currencyAdapter
            layoutManager = currencyManager
        }

        val currencyList = listOf<Views>(
            Currency("Тенге, Казахстан", 10000, R.drawable.image),
            Currency("Доллары, США", 10000, R.drawable.image),
            Currency("Доллары, США", 10000, R.drawable.image),
            Currency("Доллары, США", 10000, R.drawable.image),
            Currency("Доллары, США", 10000, R.drawable.image),
            Currency("Тенге, Казахстан", 10000, R.drawable.image),
            Add()
        )

        currencyAdapter.setItems(currencyList)
    }
}