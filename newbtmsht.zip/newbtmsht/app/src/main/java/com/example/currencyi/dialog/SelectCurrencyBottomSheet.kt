package com.example.currencyi.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.example.currencyi.R
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class SelectCurrencyBottomSheet: BottomSheetDialogFragment(){


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? =
        inflater.inflate(R.layout.select_currency_bottom_sheet, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val euroFlag = view.findViewById<TextView>(R.id.euroFlag)
        val americaFlag = view.findViewById<TextView>(R.id.americaFlag)
        val turkeyFlag = view.findViewById<TextView>(R.id.turkeyFlag)
        val russiaFlag = view.findViewById<TextView>(R.id.russiaFlag)

        russiaFlag.setOnClickListener {
            (parentFragment as? SendDataToFirstBottomSheet)?.russiaFlag(R.drawable.kz)
            dismiss()
        }

        euroFlag.setOnClickListener {
            (parentFragment as? SendDataToFirstBottomSheet)?.euroFlag(R.drawable.eu)
            dismiss()
        }

        americaFlag.setOnClickListener {
            (parentFragment as? SendDataToFirstBottomSheet)?.americaFlag(R.drawable.usa)
            dismiss()
        }

        turkeyFlag.setOnClickListener {
            (parentFragment as? SendDataToFirstBottomSheet)?.turkeyFlag(R.drawable.tur)
            dismiss()
        }

    }

    interface SendDataToFirstBottomSheet{
        fun euroFlag(res: Int)
        fun americaFlag(res: Int)
        fun turkeyFlag(res: Int)
        fun russiaFlag(res: Int)
    }
}

