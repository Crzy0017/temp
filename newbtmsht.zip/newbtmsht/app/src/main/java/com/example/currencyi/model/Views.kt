package com.example.currencyi.model

interface Views