package com.example.currencyi.firstFragment

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.example.currencyi.R

class FirstFragment : Fragment(R.layout.first_fragmrent) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }
}