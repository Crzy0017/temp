package com.example.currencyi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.currencyi.model.Add
import com.example.currencyi.model.Currency
import com.example.currencyi.model.Views
import com.example.currencyi.ui.Adapter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        setup()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_with_submenu, menu)

        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.sort_alphabet -> {
                Toast.makeText(this, "Сменить логин", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.sort_money -> {
                Toast.makeText(this, "Сменить пароль", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_no -> {
                Toast.makeText(this, "Читать новости", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setup() {
        val currencyAdapter = Adapter(
            clickListener = {
                Log.d("currency name:", it.textview)
            }
        )
        val currencyManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        findViewById<RecyclerView>(R.id.recyclerView).apply {
            adapter = currencyAdapter
            layoutManager = currencyManager
        }

        val currencyList = listOf<Views>(
            Currency("Тенге, Казахстан", 10000, R.drawable.image),
            Currency("Доллары, США", 10000, R.drawable.image),
            Currency("Доллары, США", 10000, R.drawable.image),
            Currency("Доллары, США", 10000, R.drawable.image),
            Currency("Доллары, США", 10000, R.drawable.image),
            Currency("Тенге, Казахстан", 10000, R.drawable.image),
            Add()
        )

        currencyAdapter.setItems(currencyList)
    }
}